Live Stream Player for Windows 1.50
******************
Portable Version
******************
Installation instructions:
1. Right click on install.bat and select "Run as administrator" to install required configurations and libraries
2. Double click on LiveStreamPlayer.exe to launch the application !