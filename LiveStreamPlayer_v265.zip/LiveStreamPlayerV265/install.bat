set mypath=%~dp0
REG ADD "HKEY_CLASSES_ROOT\mdc" /f /t REG_SZ /d "URL:Live Stream Player Protocol"
REG ADD "HKEY_CLASSES_ROOT\mdc" /f /v "URL Protocol" /t REG_SZ
REG ADD "HKEY_CLASSES_ROOT\mdc\DefaultIcon" /f /t REG_SZ /d "%mypath%LiveStreamPlayer.exe"
REG ADD "HKEY_CLASSES_ROOT\mdc\shell\open\command" /f /t REG_SZ /d "\"%mypath%LiveStreamPlayer.exe\" \"%%^1\""

REG ADD "HKEY_CLASSES_ROOT\live" /f /t REG_SZ /d "URL:Live Stream Player Protocol"
REG ADD "HKEY_CLASSES_ROOT\live" /f /v "URL Protocol" /t REG_SZ
REG ADD "HKEY_CLASSES_ROOT\live\DefaultIcon" /f /t REG_SZ /d "%mypath%LiveStreamPlayer.exe"
REG ADD "HKEY_CLASSES_ROOT\live\shell\open\command" /f /t REG_SZ /d "\"%mypath%LiveStreamPlayer.exe\" \"%%^1\""